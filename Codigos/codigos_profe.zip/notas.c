#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{

    FILE *arc_notas; //declaración de un puntero de tipo FILE
    arc_notas = fopen("C:\\Users\\000096175\\Documents\\programacion\\notas.txt", "r"); //abriendo el archivo en modo lectura
    int nro=0;

    char notatxt[5];
    int nota=0;

    if (arc_notas == NULL) {
        printf("Error al abrir el archivo.\n");
        return 1; //Finaliza el programa en este retirn
    }
    else {
        while (feof (arc_notas)==0)
        {
            fgets(notatxt, 5, arc_notas);
            printf("Nota: %s", notatxt); //lo imprime con el enter del archivo
            nota += atoi(notatxt);
            printf("El acumulado va en:%d \n", nota); 


        }
        
        scanf("%d",nro);
    
    }

    //fclose
    fclose(arc_notas); //cerrando el archivo
    return 0; //Instrucción final

}
