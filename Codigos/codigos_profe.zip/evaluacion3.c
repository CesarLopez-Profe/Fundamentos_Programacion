#include <stdio.h>

int main(int argc, char const *argv[])
{
    int nro_lin  = 31;
    int astxlin = (nro_lin + 1)/2;

    for (int lin = 1; lin <= nro_lin; lin++){
        for (int ast = 1; ast <= astxlin; ast++){
            if (ast >= lin) printf("*");
            else if (ast <= (nro_lin - lin)) printf(" ");
            else printf("*");
        }
        printf("\n");

    }

    return 0;
}
