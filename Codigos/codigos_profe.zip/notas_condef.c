#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{

    FILE *arc_notas; //declaración de un puntero de tipo FILE
    arc_notas = fopen("C:\\Users\\000096175\\Documents\\programacion\\notas.txt", "r"); //abriendo el archivo en modo lectura
    int nro=0;

    char notatxt[10];
    double  contnotas=1, totnotas=4;
    double acumnota=0,def=0;


    if (arc_notas == NULL) {
        printf("Error al abrir el archivo.\n");
        return 1; //Finaliza el programa en este retirn
    }
    else {
        while (fgets(notatxt, 10, arc_notas)!=NULL)
        {
            acumnota += atof(notatxt);
            if(contnotas == totnotas){
                printf("La suma de 4 notas es: %.2f \n",acumnota);
                acumnota = 0;  
                contnotas = 0;
            }
            contnotas ++;

        }
        
    }


    //fclose
    fclose(arc_notas); //cerrando el archivo
    return 0; //Instrucción final

}
