#include <stdio.h>
#include <stdlib.h>

int main() {
    int filas, cols;
    printf("Filas: "); scanf("%d", &filas);
    printf("Columnas: "); scanf("%d", &cols);

    //Se recorren las filas y por cada una de ellas se llenan las columnas
    int **mat = malloc(filas * sizeof(int*));
    for (int i = 0; i < filas; i++) {
        mat[i] = malloc(cols * sizeof(int));
    }

    // Llenar matriz con i+j
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < cols; j++) {
            mat[i][j] = i + j;
        }
    }

    // Mostrar
    printf("Matriz dinámica:\n");
    for (int i = 0; i < filas; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%3d ", mat[i][j]);
        }
        printf("\n");
    }

    // Liberar
    for (int i = 0; i < filas; i++) 
        free(mat[i]);
    
    free(mat);

    return 0;
}
