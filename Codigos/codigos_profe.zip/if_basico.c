#include <stdio.h>

int main(int argc, char const *argv[])
{
    int nro1=0, nro2=0;

    printf("Digite el primer número\n");
    scanf("%d",&nro1);
    printf("Digite el primer número\n");
    scanf("%d",&nro2);

    if (nro1 > nro2)
    {
        printf("%d es mayor que %d\n", nro1, nro2);
    }
    else if (nro1 < nro2)
    {
        printf("%d es mayor que %d\n", nro2, nro1);
    }
    else{
        printf ("Los números son iguales");
    }
    return 0;
}
