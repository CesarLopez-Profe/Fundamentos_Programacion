#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char const *argv[])
{
    FILE *arch_desp; //declaración de un puntero de tipo FILE
    arch_desp = fopen("RUTA PROPIA\\Despachos.csv", "r"); //abriendo el archivo en modo lectura

    char s[100], *fecha, *ano, *mes, *dia, *sucursal, *cantidad;
    
    //Se debe definir una variable apra llevar el acumulado del mes, del año
    //otra variable para comparar los años y meses que se van leyendo en el archivo
    //y con esta se controla cuando un mes cambie a otro y un año cambie a otro
    int cant_desp_mes = 0, cant_desp_ano = 0, ano_act = 0, mes_act = 0;

    if (arch_desp == NULL) {
        printf("Error al abrir el archivo.\n");
        return 1; //Finaliza el programa en este return
    }
    else {
        //Se debia tener en cuenta procesar la línea de titulos
        fgets(s, sizeof(s), arch_desp);

        //Se procesa el resto del archivo desde la primera línea de datos
        while (fgets(s, sizeof(s), arch_desp)!=NULL)
        {
            //Se hace el split
            fecha = strtok(s, ";");
            ano = strtok(NULL, ";");
            mes = strtok(NULL, ";");
            dia = strtok(NULL, ";");
            sucursal = strtok(NULL, ";");
            cantidad = strtok(NULL, "");

            if (fecha && ano && mes && dia && sucursal && cantidad) {
                
                //Se hacen las validaciones para el cambio de mes

                if (mes_act == atoi(mes)){
                    cant_desp_mes+=atoi(cantidad);
                }
                else if (mes_act != atoi(mes) && mes_act != 0){
                    printf("Cantidad despachada mes %d del ano %d, %d\n",mes_act, atoi(ano),cant_desp_mes);
                    cant_desp_ano+=cant_desp_mes;
                    mes_act = atoi(mes);
                    cant_desp_mes=atoi(cantidad);
                }
                else{
                    mes_act = atoi(mes);
                    cant_desp_mes=atoi(cantidad);
                }
                    
                //Se hacen las validaciones para el cambio de año
                if (ano_act != atoi(ano) && ano_act !=0 ){
                    printf("Cantidad despachada en el ano %d, %d\n", ano_act,cant_desp_ano);
                    ano_act = atoi(ano);
                    cant_desp_ano = 0;
                }
                else if (ano_act == 0)
                    ano_act = atoi(ano);
                
            } else {
                printf("Formato inválido");
            }    
        }
        //Se imprime lo que queda lleva cuando el archivo termina
        printf("Cantidad despachada mes %d del ano %d, %d\n",mes_act, ano_act,cant_desp_mes);
        cant_desp_ano+=cant_desp_mes;
        printf("Cantidad despachada en el ano %d, %d\n", ano_act,cant_desp_ano);
        
        

        fclose(arch_desp); //cerrando el archivo
        return 0;

    }
}