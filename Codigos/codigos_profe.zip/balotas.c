#include <stdio.h>

int main(int argc, char const *argv[]){
    
    char balota; //Declaración e inicialización

    printf("Coloque la inicial de su balota: ");
    scanf("%c", &balota);

    
    switch(balota){
        case 'v': printf("Invita Cervezas");
                break;
        case 'a': printf("Invita Pizza");
                break;
        case 'r': printf("Invita al postre");
                break;
        case 'b': printf("Paga el parqueadero de todos");
                break;
        
        default: printf("Opción de entrada no válida");
    }

    
    

    return 0; //Instrucción final

    
}