#include <stdio.h>

#define filas 12
#define columnas 12

void Llenar_matriz_aleat(int matriz[filas][columnas], int fil, int col ){

    //LLenar por filas
    for(int i = 0; i <= fil-1; i++){

        for(int j = 0; j <= col-1; j++){

            matriz[i][j] = rand();

        }

    }

}

void Imprimir_matriz(int matriz[filas][columnas], int fil, int col ){

    for(int i = 0; i <= fil-1; i++){

        for(int j = 0; j <= col-1; j++){
            printf ("%d \t",matriz[i][j]);
        }
        printf("\n");
    }

}

int Sumar_Diag_ppal(int matriz[filas][columnas], int fil, int col){

    if (fil == col){
        int suma=0;
        for(int i = 0; i <= fil-1; i++){
            suma += matriz[i][i];
        }
        return suma;
    }
    else return -1;

}

int Sumar_Diag_sec(int matriz[filas][columnas], int fil, int col){

    if (fil == col){
        int suma=0;
        for(int i = 0; i <= fil-1; i++){
            suma += matriz[i][fil-1-i];
        }
        return suma;
    }
    else return -1;

}

void PintarDiag(int matriz[filas][columnas], int fil, int col, char colordp[] , char colords[]){

    char reset_color[10] = "\033[0m";

    if (fil == col){

        for(int i = 0; i <= fil-1; i++){
            for(int j = 0; j <= col-1; j++){
                
                if (i==j) printf ("%s %d %s\t", colordp,matriz[i][j],reset_color);
                else if (i+j == fil-1) printf ("%s %d %s\t", colords,matriz[i][j],reset_color);
                else printf ("%d \t",matriz[i][j]);
            }
            printf("\n");
    }


    }
    else printf("No se pueden pintar diagonales en matrices no cuadraticas");
}


// Transponer la matriz (intercambiar filas por columnas)
void Transponer_matriz(int origen[filas][columnas], int destino[filas][columnas], int fil, int col){
    for(int i = 0; i < fil; i++){
        for(int j = 0; j < col; j++){
            destino[j][i] = origen[i][j];
        }
    }
}

void  Buscar_valor(int matriz[filas][columnas], int fil, int col, int valor){
    for(int i = 0; i < fil; i++){
        for(int j = 0; j < col; j++){
            if(matriz[i][j] == valor){
                printf("El valor fue encontrado en la fila %d columna %d", fil, col);  // Devuelve posición codificada
            }
        }
    }
    return -1;  // Valor no encontrado
}

//Invertir la matriz en otra matriz (inversión horizontal + vertical combinada)
void Invertir_matriz(int origen[filas][columnas], int destino[filas][columnas], int fil, int col){
    for(int i = 0; i < fil; i++){
        for(int j = 0; j < col; j++){
            destino[fil-1-i][col-1-j] = origen[i][j];
        }
    }
}


int main(int argc, char const *argv[])
{
    srand(time(NULL));
    //declaro y asigno
    int matriz_ent[5][5] = {
    {0,0,0,0,0},
    {0,0,0,0,0},
    {0,0,0,0,0},
    {0,0,0,0,0},
    {0,0,0,0,0},
   };


   char rojo[10] = "\033[31m";
   char verde[10] = "\033[32m";
   char amarillo[10] = "\033[33m";
   

   //Declarar
   int matriz1[filas][columnas], matriz2[filas][columnas];


   Llenar_matriz_aleat(matriz1, filas, columnas);
   Imprimir_matriz(matriz1,filas,columnas);

   printf("La suma de la diag principal es: %d\n", Sumar_Diag_ppal(matriz1, filas, columnas));
   printf("La suma de la diag secundaria es: %d\n", Sumar_Diag_sec(matriz1, filas, columnas));

   PintarDiag(matriz1,filas,columnas,rojo,verde);
   
   return 0;
}
