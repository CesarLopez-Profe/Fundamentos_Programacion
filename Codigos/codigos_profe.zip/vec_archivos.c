#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>

void ImprimirVector(int *vec, size_t n){
    
    for(size_t ind = 0; ind <= n-1; ind++ ){
        printf("| %d ", vec[ind]);
    }
    printf("|\n");
}


int main(int argc, char const *argv[])
{
    setlocale(LC_NUMERIC, "");

    FILE *arch_vtas; //declaración de un puntero de tipo FILE
    arch_vtas = fopen("c:\\Users\\000096175\\Documents\\programacion\\VentasxMes.csv", "r"); //abriendo el archivo en modo lectura

    char arr_split[100], *mes, *venta;
    int v_ventas[12];

    if (arch_vtas == NULL) {
        printf("Error al abrir el archivo.\n");
        return 1; //Finaliza el programa en este return
    }
    else {
        while (fgets(arr_split, sizeof(arr_split), arch_vtas)!=NULL)
        {

            mes = strtok(arr_split, ";");
            venta = strtok(NULL, "");

            if (mes && venta) {
                
                v_ventas[atoi(mes)] = atoi(venta);
            } else {
                printf("Formato inválido");
            }    
        }

        fclose(arch_vtas); //cerrando el archivo

        ImprimirVector(v_ventas,12);

        return 0;

    }
}