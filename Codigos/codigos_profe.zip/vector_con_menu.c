#include <stdio.h>
#include <string.h>
#include <time.h>

//Zona de funciones
void ImprimirVector(int *vec, size_t n){
    for(size_t ind = 0; ind <= n-1; ind++ ){
        printf("| %d ", vec[ind]);
    }
    printf("|\n");
}

void InicializarVector(int *vec, size_t n, int nro_inicial){
    //Inicializar vector con 0s
    for (size_t ind =0; ind < n; ind++){
        vec[ind] = nro_inicial;
    }
}

void LlenarVectorconAlea(int *vec, size_t n){
    //LLenar el vector con randoms
    for(size_t ind =0; ind <= n-1; ind++){
        vec[ind] = rand();
    }
}

int sumar_vector(int *vec, size_t n) {
    int result = 0;
    for (size_t i = 0; i < n; ++i) 
        result += vec[i];
    return result;
} 

double promediar_vector(int *v, size_t n) {
    if (n == 0) return 0.0;
    return (double)sumar_vector(v, n) / (double)n; //llamamos la función anterior
}

void invertir_en_nuevo(int *src, size_t n, int*dst) {

    for (size_t i = 0; i < n; ++i) {
        dst[i] = src[n - 1 - i];
    }
}



//recibe el vector, el tamaño y el vector donde va a quedar 
/*int* invertir_en_nuevo_2(int *src, size_t n) {
    int* dst[n];
    for (size_t i = 0; i < n; ++i) {
        dst[i] = src[n - 1 - i];
    }

    return dst;
}*/


//zona del main
int main(int argc, char const *argv[])
{
    srand(time(NULL)); //semilla del random
    
    int vec_int[5], vec_int_inv[5], tam_vec;
    int* vec_int_inv2;
    char opc;
    float vec_real[10];
    tam_vec = sizeof(vec_int)/sizeof(int);

    do{
        printf("*******MENU OPERACIONES VECTORES**********\n");
        printf("1. Inicializar Vector\n");
        printf("2. LLenar Vector con Aleatorios\n");
        printf("3. Sumar Elementos Vector\n");
        printf("4. Promediar Elementos Vector\n");
        printf("5. Generar Vector Elementos Invertidos\n");
        printf("6. Imprimir Vector\n");
        printf("9. Salir\n");
        printf("Digite su opcion\n");
        opc = getchar();
        while (getchar()!= '\n');
        
        

        switch (opc)
        {
        case '1':
            InicializarVector(vec_int,tam_vec,0);
            printf ("Vector inicializado\n");
            break;

        case '2':
            LlenarVectorconAlea(vec_int,tam_vec);
            printf ("Se llenó el vector con aleatorios\n");
            break;

        case '3':
            printf ("La suma de los elementos del vector es: %d\n" ,sumar_vector(vec_int,tam_vec));
            break;

        case '4':
            printf ("El promedio de los elementos del vector es: %2.f\n" ,promediar_vector(vec_int,tam_vec));
            break;
        case '5':
            //llamado a una funcion
            invertir_en_nuevo(vec_int,tam_vec,vec_int_inv);

            //llamado a la segunda función
            //vec_int_inv2 =  invertir_en_nuevo_2(vec_int,tam_vec);

            printf ("El vector invertido es: \n");
            ImprimirVector(vec_int_inv,tam_vec);
            break;
        case '6':
            ImprimirVector(vec_int,tam_vec);
            break;
        
        case '9':
            printf("Fin del menu\n");
            break;


        default:
            printf("Opción no válida\n");
            break;
        }

    }while (opc != '9');

    printf("Fin de ejecucion");

    return 0;
}

